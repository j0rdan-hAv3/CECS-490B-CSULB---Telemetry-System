/*
 * MPU6050.c
 *
 *	Main implementation of functions to interact with
 *	the 6-dof MPU6050 Accelerometer and Gyroscope
 *
 *
 */
 
#include "MPU6050.h"

/*
 *	-------------------MPU6050_Init---------------------
 *	Basic Initialization Function for MPU6050 @ default settings
 *	Input: none
 * 	Output: none
 */


uint8_t sendData;

void MPU6050_InitData(void){
	sendData = wakeup; // wake up and set clock to internal clock (8MHz oscillator) for the time being
	HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR_AD0_LOW, PWR_MGMT_1, 1, &sendData, 1, HAL_MAX_DELAY);
	sendData = CONFIG_DFPL_3;
	HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR_AD0_LOW, CONFIG, 1, &sendData, 1, HAL_MAX_DELAY);
	sendData = SampleRateDivider; // set sample rate to 1 kHz/(1+4) = 200 Hz (seen on page 12 of Datasheet)
	HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR_AD0_LOW, SMPLRT_DIV, 1, &sendData, 1, HAL_MAX_DELAY);
	sendData = GyroConfigValue; // set Gyro to +- 250 dps which is highest resolution and lowest range
	HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR_AD0_LOW, GYRO_CONFIG, 1, &sendData, 1, HAL_MAX_DELAY);
	sendData = AccelConfigValue; // set Accel to full-scale range 2g (good precision but limited range)
	HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR_AD0_LOW, ACCEL_CONFIG, 1, &sendData, 1, HAL_MAX_DELAY);
}



void MPU6050_Get_Temp(MPU6050_Temp_t* Temperature_Instance){
	uint8_t tempData[2];

	HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR_AD0_LOW, TEMP_OUT_H, I2C_MEMADD_SIZE_8BIT, tempData, 2, HAL_MAX_DELAY);

	Temperature_Instance->tempRaw = (int16_t)((tempData[0] << 8) | tempData[1]); // get Raw data of temperature sensor

	Temperature_Instance->temp = ((float)Temperature_Instance->tempRaw / 340.0f) + 36.53f;
}

void MPU6050_GetAccelData(MPU6050_ACCEL_t* Accel_Instance){
	uint8_t accelData[6];

	HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR_AD0_LOW, ACCEL_XOUT_H, I2C_MEMADD_SIZE_8BIT, accelData, 6, HAL_MAX_DELAY);


	Accel_Instance->Ax_RAW = (int16_t) ((accelData[0] << 8) | accelData[1]);
	Accel_Instance->Ay_RAW = (int16_t) ((accelData[2] << 8) | accelData[3]);
	Accel_Instance->Az_RAW = (int16_t) ((accelData[4] << 8) | accelData[5]);
}

void MPU6050_ProcessAccelData(MPU6050_ACCEL_t* Accel_Instance){
	// acquire acceleration in units of g
	AxAccel = Accel_Instance->Ax = (float)Accel_Instance->Ax_RAW / ACCEL_LSB_0_VALUE;
	AyAccel = Accel_Instance->Ay = (float)Accel_Instance->Ay_RAW / ACCEL_LSB_0_VALUE;
	AzAccel = Accel_Instance->Az = (float)Accel_Instance->Az_RAW / ACCEL_LSB_0_VALUE;

	AxAccel = AxAccel * 9.81f;
	AyAccel = AyAccel * 9.81f;
	AzAccel = AzAccel * 9.81f;
}

void MPU6050_ProcessGyroData(MPU6050_GYRO_t* Gyro_Instance){
	// Raw Gyroscope measurements into angular velocity in degrees/s
	Gyro_Instance->Gx = (float)Gyro_Instance->Gx_RAW / GYRO_LSB_0_VALUE;
	Gyro_Instance->Gy = (float)Gyro_Instance->Gy_RAW / GYRO_LSB_0_VALUE;
	Gyro_Instance->Gz = (float)Gyro_Instance->Gz_RAW / GYRO_LSB_0_VALUE;
}


void MPU6050_GetGyroData(MPU6050_GYRO_t* Gyro_Instance){
	uint8_t gyroData[6];

	HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR_AD0_LOW, GYRO_XOUT_H, I2C_MEMADD_SIZE_8BIT, gyroData, 6, HAL_MAX_DELAY); // does this work to get Gyro Information?

	Gyro_Instance->Gx_RAW = (int16_t)(gyroData[0] << 8 | gyroData[1]);
	Gyro_Instance->Gy_RAW = (int16_t)(gyroData[2] << 8 | gyroData[3]);
	Gyro_Instance->Gz_RAW = (int16_t)(gyroData[4] << 8 | gyroData[5]);

}

void MPU6050_GetAngle(MPU6050_ACCEL_t* Accel_Instance, MPU6050_GYRO_t* Gyro_Instance, MPU6050_ANGLE_t* Angle_Instance, float t){
	 //convert raw to SI units
//	float Ax = Accel_Instance->Ax * 9.81f; // g -> m/s^(2)
//	float Ay = Accel_Instance->Ay * 9.81f;
//	float Az = Accel_Instance->Az * 9.81f;


	// Raw acceleration data
	float Ax = Accel_Instance->Ax; // g -> m/s^(2)
	float Ay = Accel_Instance->Ay;
	float Az = Accel_Instance->Az;

	float Gx = Gyro_Instance->Gx / t;
	float Gy = Gyro_Instance->Gy / t;

	float Gyro_Angle;
	Gyro_Angle = Gyro_Instance->Gz / t;

	uint8_t pitchoffset = 3;
	uint8_t rolloffset = 5;
	//roll += Gx*t;
	//pitch += Gy * t;

	// Accelerometer angles
	//float accelRoll = atan2f(Ay, Az) * RAD_TO_DEGREE_CONV;
	//float accelPitch = atan2f(-Ax, sqrtf(Ay*Ay + Az*Az)) * RAD_TO_DEGREE_CONV;

	// Complimentary filter
	//roll = alpha * roll + (1.0f - alpha) * accelRoll;
	//	pitch = alpha * pitch + (1.0f - alpha)* accelPitch;


//	Angle_Instance->ArX = atan2f((Accel_Instance->Ay), (Accel_Instance->Az)) * RAD_TO_DEGREE_CONV;
//	Angle_Instance->ArY = atan2f(Accel_Instance->Ax, Accel_Instance->Az) * RAD_TO_DEGREE_CONV;

	//Angle_Instance->ArX = atan2f(Ay, Az) * RAD_TO_DEGREE_CONV; // Roll is x axis
	//roll = atan2f(Ay, sqrtf(Ax*Ax + Az *Az)) * RAD_TO_DEGREE_CONV;
	//pitch = atan2f(-Ax, sqrtf(Ay*Ay + Az *Az)) * RAD_TO_DEGREE_CONV; // pitch is y axis
	Angle_Instance->ArX = (atan2f(Ay, sqrtf(Ax*Ax + Az *Az)) * RAD_TO_DEGREE_CONV); // Roll is x axis (tilt angle)
	Angle_Instance->ArY = (atan2f(-Ax, sqrtf(Ay*Ay + Az *Az)) * RAD_TO_DEGREE_CONV); // pitch is y axis


	// Adjust offset for Roll and Pitch
	if (Angle_Instance->ArX < 0){
		Angle_Instance->ArX -= -(rolloffset);
	}else {
		Angle_Instance->ArX += rolloffset;
	}

	if (Angle_Instance->ArY < 0){
		Angle_Instance->ArY -= -(pitchoffset);
	}else {
		Angle_Instance->ArY += pitchoffset;
	}

	float Gyro_Angle_Scale = 0.5f;
	float deadzone = 5;

	if (Gyro_Angle > deadzone || Gyro_Angle < -deadzone){
		Angle_Instance->ArZ += Gyro_Angle * Gyro_Angle_Scale;
	}
}


void MPU6050_Test(float t, float dt){

	// Temperature (for onboard chip)
	MPU6050_Temp_t myTemp;
	MPU6050_Get_Temp(&(myTemp));
	tempC = (int32_t) myTemp.tempRaw * 1000 / 340 + 36530;

	// Accelerometer
	MPU6050_ACCEL_t myAccel;
	MPU6050_GetAccelData(&(myAccel));

	// Gyroscope
	MPU6050_GYRO_t myGyro;
	MPU6050_GetGyroData(&(myGyro));

	// Angle
	MPU6050_ANGLE_t myAngle;


	// Process Raw Accelerometer and Gyroscope data
	MPU6050_ProcessAccelData(&myAccel);
	MPU6050_ProcessGyroData(&myGyro);

	// Calculate tilt angle
	MPU6050_GetAngle(&myAccel, &myGyro, &myAngle, dt);



	// Kalman Filter Call(not working yet)
//	kalman_1D(KalmanAngleRoll, KalmanUncertaintyAngleRoll, myGyro.Gx, roll); // Angle Roll and RateRoll is not defined
//	KalmanAngleRoll = Kalman1DOutput[0];
//	KalmanUncertaintyAngleRoll = Kalman1DOutput[1];
//	kalman_1D(KalmanAnglePitch, KalmanUncertaintyAnglePitch, myGyro.Gy, pitch);
//	KalmanAnglePitch=Kalman1DOutput[1];

	// New Output for IMU


	angleX = (int)myAngle.ArX;
	angleY = (int)myAngle.ArY;
	angleZ = (int)myAngle.ArZ;

	snprintf(tempBuffer, sizeof tempBuffer, "TEMP(IMU): %.2f *C\r\n", (float)(tempC) / 1000.0f);
	snprintf(angularData, sizeof angularData, "ANGLE(x, y, z): (%3d, %3d, %3d)*\r\n", angleX, angleY, angleZ);
	snprintf(accelData,sizeof accelData, "SPEED(x, y, z): (%3d, %3d, %3d) m/s^2\n\r\n", (int)AxAccel, (int)AyAccel, (int)AzAccel);
}



//void kalman_1D(float KalmanState, float KalmanUncertainty, float KalmanInput, float KalmanMeasurement){
//	// KalmanInput = rotation rate
//	// KalmanMeasusrement = accelerometer angle
//	// KalmanState = angle calculated with Kalman filter
//	KalmanState = KalmanState + 0.004 * KalmanInput;
//	KalmanUncertainty = KalmanUncertainty + 0.004 *0.004*4*4;
//	float KalmanGain = KalmanUncertainty * 1/ (1 * KalmanUncertainty + 3*3);
//	KalmanState = KalmanState + KalmanGain * (KalmanMeasurement - KalmanState);
//	KalmanUncertainty = (1-KalmanGain) * KalmanUncertainty;
//
//	// Kalman Filter Output
//	Kalman1DOutput[0] = KalmanState;
//	Kalman1DOutput[1] = KalmanUncertainty;
//}
