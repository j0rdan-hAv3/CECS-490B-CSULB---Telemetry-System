/*
 * BMP388.h
 *
 *  Created on: Sep 23, 2025
 *      Author: Cesar Hernandez
 */
#include "main.h"
extern I2C_HandleTypeDef hi2c1;
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#ifndef BMP388_H_
#define BMP388_H_

//#define BMP388_I2C_Address (0x76) // given on pg 39; address could also be 0x77 if connecting SDO to GND results in slave address
#define BMP388_I2C_Address (0x77 << 1) // address that gets detected

// Register Addresses
#define Command 		0x7E // Command Register Address
#define ConfigIIR  		0x1f // configuration for IIR filter
#define ODR				0x1D // ODR select register
#define OSR				0x1C // OSR_T and OSR_P registers
#define PowerCTRL 		0x1B // Mode and Temp Enable, Pressure Enable
#define IF_CONF  		0x1A // I2C select and enabe, and SPI3
#define INT_CTRL 		0x19 // Interrupt Enable Register
#define FIFO_Config2 	0x18 // Data select and fifo subsampling
#define FIFO_Config1 	0x17 // Fifo register address
#define FIFO_WTM_1   	0x16 // FIFO Watermark 8 bit
#define FIFO_WTM_0	 	0x15 // FIFO Watermark 7-0 bits
#define FIFO_DATA	 	0x14 // Fifo Data
#define FIFO_LENGTH_1 	0x13 // FIFO_BYTE_COUNTER_8 bit 8
#define FIFO_LENGTH_0 	0x12 // FIFO Bits 7-0
#define INT_STATUS	  	0x11 // Data Ready, FIFO FULL Interupt, FWM_INT
#define EVENT		 	0x10 // POR_Detected
#define SENSORTIME_2 	0x0E // Sensor TIme bits 23-16
#define SENSORTIME_1 	0x0D // Sensor Time bits 15-8
#define SENSORTIME_0 	0x0C // Sensor Time bits 7-0

// Data Bit Register Address

// Temperature Data Addresses
#define Data_5 			0x09 // Temperature Data bits 23-16
#define Data_4 			0x08 // Temperature Data bits 15-8
#define Data_3 			0x07 // Temperature Data bits 7-0

// Altitude Data Address (Pressure data)
#define Data_2 			0x06 // Pressure Data bits 23-16
#define Data_1 			0x05 // Pressure Data bits 15-8
#define Data_0 			0x04u // Pressure Data bits 7-0

#define STATUS			0x03 // Bits 6(Temperature Data Ready), Bits 5 (Pressure Data ready), Bits 4 (command decoder ready)
#define ERR_ERG			0x02 // Bits 2(Conf error), Bits 1(Command Error), Bits 0 (Fatal Error)
#define CHIP_ID 		0x00 // Chip ID (Bits 7-4) and CHIP ID NVM (Bits 3-0)


// Data Ready Bits
#define cmd_rdy			0x10 // Bit 4 0001_0000
#define drdy_press 		0x20u // Bit 5 0010_0000
#define drdy_temp		0x40u // Bit 6 0100_0000

// Pressure Measurement				Pressure Oversampling		Pressure Resolution			Recommended Temp Oversampling
#define UltraLowPower 	0x000	 	//  		x1					   16 bit/2.64  Pa						x1
#define LowPower	  	0x001		// 			x2					   17 bit/1.32  Pa						x1
#define StandardP	 	0x010		// 			x4					   18 bit/0.66  Pa						x1
#define HighResolP	  	0x011		// 			x8					   19 bit/0.33  Pa						x1
#define UltraHighResoP  0x100		//			x16					   20 bit/0.17  Pa						x2
#define HighestResoP	0x101		//			x32					   21 bit/0.085 Pa						x2


// Temperature Measurement			Temperature Oversampling			Typical Temperature Resolution
#define UltraLowT		0x000		// 			x1								16 bit / 0.0050 °C
#define LowPowerT		0x001		// 			x2 								17 bit / 0.0025 °C
#define StandardT		0x010		// 			x4								18 bit / 0.0012 °C
#define HighResoT		0x011		// 			x8								19 bit / 0.0006 °C
#define UltraHighResoT	0x100		// 			x16								20 bit / 0.0003 °C
#define HighestResoT	0x101		// 			x32								21 bit / 0.00015 °C


// Mode selection
// 110000
#define SleepM			(0b00u << 4) // configure mode to Sleep
#define NormalM			(0b11u << 4) // configure mode to Normal
#define ForcedM			(0b01u << 4) // configure mode to Forced

// Enable Sensors
#define pressEn			(0b1u)		// enable pressure sensor; equivalent to 0x01
#define tempEn			(0b1u << 1) // enable temperature sensor; equivalent to 0x02

#define NormalEnableTP	(pressEn | tempEn | NormalM)

// Sea level pressure (Long Beach, CA) value
#define SeaLevelPressure (1013.25f)		// in hPa measurement

// ODR: Output Data Rate
#define ODR_200			0x00		// ODR 200 Hz; 5ms
#define ODR_100			0x01		// ODR 100 Hz; 10ms
#define ODR_50			0x02		// ODR 50  Hz; 20ms
#define ODR_25			0x03		// ODR 25 Hz; 40ms
#define ODR_12p5		0x04		// ODR 25/2 Hz; 80ms
#define ODR_6p25		0x05		// ODR 25/4 Hz; 160ms
#define ODR_3p1			0x06		// ODR 25/8 Hz; 320ms
#define ODR_1p5			0x07		// ODR 25/18 Hz; 640ms
#define ODR_0p78		0x08		// ODR 25/32 Hz; 1.280s
#define ODR_0p39		0x09		// ODR 25/64 Hz; 2.560s
#define ODR_0p2			0x0A		// ODR 25/128 Hz; 5.120s
#define ODR_0p1			0x0B		// ODR 25/256 Hz; 10.24s
#define ODR_0p05		0x0C		// ODR 25/512 Hz; 20.48s
#define ODR_0p02		0x0D		// ODR 25/1024 Hz; 40.96s
#define ODR_0p01		0x0E		// ODR 25/2048 Hz; 81.92s
#define ODR_0p006		0x0F		// ODR 25/4096 Hz; 163.84s
#define ODR_0p003		0x10		// ODR 25/8192 Hz; 327.68s
#define ODR_0p0015		0x11		// ODR 25/16384 Hz; 655.36s

#define NVNPAT1			0x31		// NVM_PAR_T1 <7:0> raw temperature register; Non-Volatile Memory

// Config bits for IIR filter
#define coef_0			(0b000u << 1)		// filter coefficient 0->bypass mode
#define coef_1			(0b001u << 1)		// filter coefficient 1
#define coef_3			(0b010u << 1)		// filter coefficient 3
#define coef_7			(0b011u << 1)		// filter coefficient 7
#define coef_15			(0b100u << 1)		// filter coefficient 15
#define coef_31			(0b101u << 1)		// filter coefficient 31
#define coef_63			(0b110u << 1)		// filter coefficient 63
#define coef_127		(0b111u << 1)		// filter coefficient 127


// OSR Oversampling data setting for pressure measurement
#define pnoOSampling		(0b000u)	// no oversampling
#define px2OSampling		(0b001u)	// x2 oversampling
#define px4OSampling		(0b010u)	// x4 oversampling
#define px8OSampling		(0b011u)	// x8 oversampling
#define px16OSampling		(0b100u)	// x16 oversampling
#define px32OSampling		(0b101u)	// x32 oversampling


// 000 001
// OSR Oversampling data setting for temperature measurement
#define tnoOSampling		(0b000u << 3)	// no oversampling
#define tx2OSampling		(0b001u << 3)	// x2 oversampling
#define tx4OSampling		(0b010u << 3)	// x4 oversampling
#define tx8OSampling		(0b011u << 3)	// x8 oversampling
#define tx16OSampling		(0b100u << 3)	// x16 oversampling
#define tx32OSampling		(0b101u << 3)	// x32 oversampling

// Calibration struct
typedef struct{
	// PAR* coefficients
	float par_t1, par_t2, par_t3; // raw temperature sensor data registers
	float par_p1, par_p2, par_p3, par_p4, par_p5, par_p6, par_p7, par_p8, par_p9, par_p10, par_p11; // raw pressure sensor data
	float t_lin; //
}BMP388_Calib;
// Data registers


// Function Declarations
void BMP388_Configuration(void);


// Given in Datasheet page 54 & 55
static float BMP388_compensate_temperature(uint32_t uncomp_temp, BMP388_Calib *cal);
static float BMP388_compensate_pressure(uint32_t uncomp_temp, BMP388_Calib *cal);

//static float bmp388_comp_temp(uint32_t temp_u24, BMP388_Calib *cal);
static float bmp388_comp_press(uint32_t press_u24, const BMP388_Calib *cal);

bool BMP388_Run();

bool BMP388_ReadCalib(BMP388_Calib *cal);
bool BMP388_ReadData(BMP388_Calib *cal, float* temp_c, float* press_Pa, float *altitude_m);

#endif /* BMP388_H_ */
