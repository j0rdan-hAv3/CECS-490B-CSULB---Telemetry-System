/*
 * uart5.h
 *
 *  Created on: November 2, 2025
 *      Author: Jordan H. and James H.
 *		Description: Header file for uart5.c
 */

#include "stm32f4xx_hal.h"
#include <stddef.h>
#ifdef __cplusplus
extern "C" { #endif

extern UART_HandleTypeDef huart5; // UART5 handler

void UART5_LoRa_Init(void); // Initialize UART5

// Helper functions
void UART5_SendBytes(const uint8_t* data, uint16_t len, uint32_t timeout_ms);

// Main functions
void UART5_SendString(const char* s, uint32_t timeout_ms);

#ifdef __cplusplus
}
#endif
#endif
