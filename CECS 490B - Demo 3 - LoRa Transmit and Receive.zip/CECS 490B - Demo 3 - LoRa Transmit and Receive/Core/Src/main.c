/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention: Left off working on configuring Z axis
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "uart5.h" // Added by Jo
#include "MPU6050.h"
#include "BMP388.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
I2C_HandleTypeDef hi2c1;
DMA_HandleTypeDef hdma_i2c1_tx;
DMA_HandleTypeDef hdma_i2c1_rx;
//UART_HandleTypeDef huart2;


/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);

float roll = 0.0f;
float pitch = 0.0f;

float Ax, Ay, Az;
/* USER CODE END PV */

void kalman_1D(float KalmanState, float KalmanUncertainty, float KalmanInput, float KalmanMeasurement);

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

float Gyro_Angle;
uint8_t buffer[64];

// Data receiving variable
uint8_t Receive_Data[14];
uint8_t checkVal;

float KalmanAngleRoll = 0, KalmanUncertaintyAngleRoll = 2*2;
float KalmanAnglePitch =0, KalmanUncertaintyAnglePitch = 2*2; // Define the predicated angles and uncertainty
float Kalman1DOutput[] = {0,0}; // initialize the output of filter {angle prediction, uncertainty of the prediction}


MPU6050_ACCEL_t myAccel;

// Global buffers for MPU6050
char abuff[64]; // roll and pitch
char accelData[64];	   // Acceleration data for each axis
char angularData[64];  // Angular data for each axis
char tempBuffer [64]; // Temperature buffer for UART output

// global buffer for BMP388
char line[128];

// timer
float dt;
uint32_t pTick;
uint32_t current;

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */

int main(void){
	  /* USER CODE BEGIN 1 */

	  /* USER CODE END 1 */

	  /* MCU Configuration--------------------------------------------------------*/

	  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	  HAL_Init();
	  /* USER CODE BEGIN Init */

	  /* USER CODE END Init */

	  /* Configure the system clock */
	  SystemClock_Config();

	  /* USER CODE BEGIN SysInit */

	  /* USER CODE END SysInit */

	  /* Initialize all configured peripherals */
	  MX_GPIO_Init();
	  MX_I2C1_Init();
	  MX_USART2_UART_Init();
	  UART5_LoRa_Init(); // Added by Jo
	  /* USER CODE BEGIN 2 */
	  HAL_StatusTypeDef result;
	  HAL_StatusTypeDef result2;
	  uint8_t checkVal=0;
	  uint8_t checkVal2=0;
	  char conn1[25];
	  char conn2[25];
	  result2 = HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR_AD0_LOW, WHO_AM_I, I2C_MEMADD_SIZE_8BIT, &checkVal, 1, HAL_MAX_DELAY);
	  result = HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, CHIP_ID, I2C_MEMADD_SIZE_8BIT, &checkVal2, 1, 100);

	  // Checking to see if Modules are detected over I2C
	  if (result == HAL_OK || result2 == HAL_OK){
		  if(checkVal == 0x68){
			  snprintf(conn1,sizeof conn1, "MPU6050 Detected\r\n");
			  HAL_UART_Transmit(&huart2, (uint8_t*) conn1, strlen(conn1), HAL_MAX_DELAY);
			  UART5_SendString((char*) conn1, 1000); // Added by Jo
			  MPU6050_InitData();
		  }else{
			  snprintf(conn1,sizeof conn1, "MPU6050 Not Detected\r\n");
			  HAL_UART_Transmit(&huart2, (uint8_t*) conn1, strlen(conn1), HAL_MAX_DELAY);
			  UART5_SendString((char*) conn1, 1000); // Added by Jo
			  return;
		  }

		  if(checkVal2 == 0x50){
			  snprintf(conn2, sizeof conn2, "BMP388 Detected\r\n");
			  HAL_UART_Transmit(&huart2, (uint8_t*) conn2, strlen(conn2), HAL_MAX_DELAY);
			  UART5_SendString((char*) conn2, 1000); // Added by Jo
			  BMP388_Configuration();

		  }else{
			  snprintf(conn2, sizeof conn2, "BMP388 Not Detected\r\n");
			  HAL_UART_Transmit(&huart2, (uint8_t*) conn2,strlen(conn2), HAL_MAX_DELAY);
			  UART5_SendString((char*) conn2, 1000); // Added by Jo
			  return;
		  }


		  while(1){
			  static uint32_t last = 0;
			  current = HAL_GetTick();
			  bool IMU = MPU6050_Run();
			  bool Baro = BMP388_Run();

			  if(current - last >= 500){ // should print out every 100 ticks ~= 100ms which is ~10 Hz
				  	last = current;
			  		// MPU6050 Output to terminal
			  	  	char borders[64];
			  	  	snprintf(borders, sizeof borders, "-------------------------------------\r\n");

			  	  	HAL_UART_Transmit(&huart2, (uint8_t*) borders, strlen(borders), HAL_MAX_DELAY);
			  	  	UART5_SendString(borders, 750); // Added by Jo
				  	HAL_UART_Transmit(&huart2,(uint8_t*) tempBuffer, (strlen(tempBuffer)), HAL_MAX_DELAY);
			  	  	UART5_SendString(tempBuffer, 750); // Added by Jo
			  		HAL_UART_Transmit(&huart2,(uint8_t*) angularData, (strlen(angularData)), HAL_MAX_DELAY);
			  	  	UART5_SendString(angularData, 750); // Added by Jo
			  		HAL_UART_Transmit(&huart2,(uint8_t*) accelData, (strlen(accelData)), HAL_MAX_DELAY);
			  	  	UART5_SendString(accelData, 750); // Added by Jo


			  		// BMP388 Output to terminal
			  		HAL_UART_Transmit(&huart2, (uint8_t*)line, strlen(line), HAL_MAX_DELAY);
			  	  	UART5_SendString(line, 750); // Added by Jo
			  	  	HAL_UART_Transmit(&huart2, (uint8_t*) borders, (strlen(borders)), HAL_MAX_DELAY);
			  	  	UART5_SendString(borders, 750); // Added by Jo
			  	}
		  }
	  }
	  /* USER CODE END 2 */

	  /* Infinite loop */
	  /* USER CODE BEGIN WHILE */
//	  while (1){
//	  }

}


bool BMP388_Run(void){
	  HAL_StatusTypeDef result;
	  uint8_t checkVal=0;
	  BMP388_Calib cal;
	  char buff[20];
	  // Compares BMP388_I2C_Address value to the BMP388 ID value in CHIP_ID and checkVal will contain the byte read from register 0x00
	  // so I can use an if statement to make sure that the sensor that was read is the one we want. For this example we will compare
	  // checkVal to 0x50 as 0x50 is the default value for CHIP_ID (chip identification number)
	  result = HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, CHIP_ID, I2C_MEMADD_SIZE_8BIT, &checkVal, 1, 100);

	  HAL_Delay(4);
	  if (result == HAL_OK){
		  if(checkVal == 0x50){
			  // Success: The sensor is getting detected
//			  snprintf(buff, sizeof buff,"BMP388 Detected\n\r" );
//			  HAL_UART_Transmit(&huart2, buff, strlen(buff), HAL_MAX_DELAY);
			  //BMP388_Configuration();  // you already have this (does reset + config)

			  // Read & convert calibration once

			  if (!BM388_DataCalibration(&cal)) {
			      const char *msg = "Calib read failed\r\n";
			      HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
			      return false;
			  }
			  } else{
				  snprintf(buff, sizeof buff, "BMP388 Not Detected\n\r");
				  HAL_UART_Transmit(&huart2, buff,  strlen(buff), HAL_MAX_DELAY);
				  return false;
			  }
			  } else{
				  snprintf(buff, sizeof buff, "No I2C connection\n\r");
				  HAL_UART_Transmit(&huart2, buff, strlen(buff), HAL_MAX_DELAY);
				  return false;
			  }



	    /* USER CODE END WHILE */
	  	  // Status is used to determine that the Pressure and Temperature data is ready to be read
		  uint8_t status = 0;
		  HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, STATUS, I2C_MEMADD_SIZE_8BIT, &status, 1, HAL_MAX_DELAY);

		  do {
		      HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, STATUS, I2C_MEMADD_SIZE_8BIT, &status, 1, HAL_MAX_DELAY);
		  } while ((status & (drdy_press|drdy_temp)) != (drdy_press|drdy_temp));

		  float temp_C, press_Pa, altitude;
		  if (BMP388_ReadData(&cal, &temp_C, &press_Pa, &altitude)) {
			  HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, STATUS, I2C_MEMADD_SIZE_8BIT, &status, 1, HAL_MAX_DELAY);

			  snprintf(line, sizeof line, "\x1b[33m" "Pressure: %.2f Pa \r\n"
			  							  "\x1b[34m" "Approx. Altitude: %.2f m\r\n"
					  	  	  	  	  	  "\x1b[32m" "Temperature: %.2f *C \r\n" "\x1b[0m", press_Pa, altitude, temp_C);
//			  snprintf(line, sizeof line,"\x1b[32m" "Temperature: %.2f *C \r\n"
//										 "\x1b[33m" "Pressure: %.2f hPa\r\n"
//										 "\x1b[34m" "Approx. Altitude: %.2f m\n\r\n" "\x1b[0m", temp_C, (press_Pa / 100), altitude);
			  //HAL_UART_Transmit(&huart2, (uint8_t*)line, strlen(line), HAL_MAX_DELAY);
			  }
			  HAL_Delay(20); // ~50 Hz matches your ODR
		  //}
	    /* USER CODE BEGI 3 */
			 return true;
			  /* USER CODE END 3 */
	}


// Have to configure the buffers for this function. BMP388 can have data buffer be global and then outputted from main function
bool MPU6050_Run(void){

	  HAL_StatusTypeDef result;

	  result = HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR_AD0_LOW, WHO_AM_I, I2C_MEMADD_SIZE_8BIT, &checkVal, 1, HAL_MAX_DELAY);
	  pTick = HAL_GetTick(); //
	  if (result == HAL_OK){
		  if (checkVal == 0x68){
			 MPU6050_Test(current, dt);
		  } else{
			  sprintf(buffer, "Not connected to MPU6050\r\n");
			  HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen((char*)buffer), HAL_MAX_DELAY);
			  return false;
		  }
	  }

	  return true;

}

void kalman_1D(float KalmanState, float KalmanUncertainty, float KalmanInput, float KalmanMeasurement){
	// KalmanInput = rotation rate
	// KalmanMeasusrement = accelerometer angle
	// KalmanState = angle calculated with Kalman filter
	KalmanState = KalmanState + 0.004 * KalmanInput;
	KalmanUncertainty = KalmanUncertainty + 0.004 *0.004*4*4;
	float KalmanGain = KalmanUncertainty * 1/ (1 * KalmanUncertainty + 3*3);
	KalmanState = KalmanState + KalmanGain * (KalmanMeasurement - KalmanState);
	KalmanUncertainty = (1-KalmanGain) * KalmanUncertainty;

	// Kalman Filter Output
	Kalman1DOutput[0] = KalmanState;
	Kalman1DOutput[1] = KalmanUncertainty;
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
