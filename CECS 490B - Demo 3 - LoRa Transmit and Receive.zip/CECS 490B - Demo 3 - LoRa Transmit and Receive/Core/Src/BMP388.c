/*
 * BMP388.c
 *
 *  Created on: Sep 24, 2025
 *      Author: Cesar Hernandez
 */

#include "BMP388.h"

void BMP388_Configuration(void){
	// Drone Configuration:
	// 		Mode: Normal, Over-sampling Setting: Standard Resolution, osrs_p: x8, osrs_t: x1,
	//			  IIR Filter Coeff: 2, Idd: 570 µA, ODR: 50 Hz, RMS Noise: 11 (cm)

	// we will be configuring this based on the Drone configuration on pg 16 for filter selection

	// Reset registers in BMP388
	uint8_t softReset = 0xB6;
	HAL_I2C_Mem_Write(&hi2c1, BMP388_I2C_Address, Command, I2C_MEMADD_SIZE_8BIT, &softReset, 1, HAL_MAX_DELAY);

	// check ready status
	uint8_t status, err;
	do {
	  HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, STATUS, I2C_MEMADD_SIZE_8BIT, &status, 1, HAL_MAX_DELAY);
	} while ((status & (1<<4)) == 0); // cmd_rdy

	// Make sure to check the value of ERR_ERG
	HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, ERR_ERG, I2C_MEMADD_SIZE_8BIT, &err, 1, HAL_MAX_DELAY);
	
	// Select mode and enable both pressure(0x01)/temp(0x02) sensors
	uint8_t modeSelect = NormalEnableTP; // get hexadecimal value for Normal Mode
	HAL_I2C_Mem_Write(&hi2c1, BMP388_I2C_Address, PowerCTRL, I2C_MEMADD_SIZE_8BIT, &modeSelect, 1, HAL_MAX_DELAY); // connects to Power_Management Register

	// Configure Oversampling (OSR): osrs_p = x8, osrs_t = x1
	//uint8_t osrPSelect = 0x03; // bit2-0: for x8 = 011
	//uint8_t osrTSelect = 0x00; // bit5-3: for x1 = 000

	//uint8_t osrSelect =  (osrTSelect << 3) | osrPSelect;
	uint8_t osrSelect = tnoOSampling | px8OSampling;

	HAL_I2C_Mem_Write(&hi2c1, BMP388_I2C_Address, OSR, I2C_MEMADD_SIZE_8BIT, &osrSelect, 1, HAL_MAX_DELAY);

	// Configure IIR Filter (ConfigIIR)
	uint8_t IIRSelect = coef_3; // 0x03: 0000 1000 ->

	HAL_I2C_Mem_Write(&hi2c1, BMP388_I2C_Address, ConfigIIR, I2C_MEMADD_SIZE_8BIT, &IIRSelect, 1, HAL_MAX_DELAY);

	// Set output data rate (ODR)
	uint8_t outputRate = ODR_50; // set output frequency to 50 Hz name of it is ODR_50; Sampling Period: 20ms
	HAL_I2C_Mem_Write(&hi2c1, BMP388_I2C_Address, ODR, I2C_MEMADD_SIZE_8BIT, &outputRate, 1, HAL_MAX_DELAY);

	// Check Sensor Status Flags: Bit 4 (cmd_rdy), Bit 5 (drdy_press), Bit 6 (drdy_temp)


	// Temperature Data: registers Data_5(0x09), Data_4(0x08), and Data_3(0x07)
	

	// Pressure Data: registers Data_2 (0x06), Data_1(0x05), Data_0(0x04)

	/* Steps for Initializing BMP388
	 *
	 * 1. Read chip ID (0x00) and confirm that its 0x50 (check)
	 * 2. Write 0xB6 to reset (0x7E), wait for completion (not done)
	 * 3. Read calibration dta from 0x31-0x5F into your software
	 * 4. Configure: PWR_CTRL(0x1B)-> enable pressure+temp+sensor
	 * 	  			 OSR(0x1C), ODR(0x1D), CONFIG(0x1F) registers as needed
	 * 5. Poll Status (0x03) or wait for data ready interrupt
	 * 6. Read raw pressure/temperature (0x04-0x09)
	 * 7. Apply compensation using calibration constants
	 */
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////Given in datasheet pg 54 /////////////////////////////////////////////////////////////////////////////////////

// Temperature compensation found in Appendix 9 on page 54
static float BMP388_compensate_temperature(uint32_t uncomp_temp, BMP388_Calib *cal){
	float partial_data1;
	float partial_data2;

	partial_data1 = ((float)uncomp_temp - cal->par_t1);
	partial_data2 = ((float)partial_data1 * cal->par_t2);
	/*
	 * 	Update the compensated temperature in calib structure since this is
	 * 	needed for pressure calculation
	 */
	cal->t_lin = partial_data2 + (partial_data1*partial_data1) * cal->par_t3;

	// Return compensated temperature
	return cal->t_lin;
}

// Pressure compensation
static float BMP388_compensate_pressure(uint32_t uncomp_press, BMP388_Calib *cal){
	// Variable to store the compensated pressure
	float comp_press;

	// Temporary variable used for compensation
	float partial_data1;
	float partial_data2;
	float partial_data3;
	float partial_data4;
	float partial_out1;
	float partial_out2;

	/*
	 * Calibration data
	 */

	partial_data1 = cal->par_p6 * cal->t_lin;
	partial_data2 = cal->par_p7 * (cal->t_lin * cal->t_lin);
	partial_data3 = cal->par_p8 * (cal->t_lin * cal->t_lin * cal->t_lin);
	partial_out1 = cal->par_p5 + partial_data1 + partial_data2 + partial_data3;

	partial_data1 = cal->par_p2 * cal->t_lin;
	partial_data2 = cal->par_p3 *(cal->t_lin * cal->t_lin);
	partial_data3 = cal->par_p4 *(cal->t_lin * cal->t_lin * cal->t_lin);
	partial_out2 = (float)uncomp_press * (cal->par_p1 + partial_data1 + partial_data2 + partial_data3);


	partial_data1 = (float)uncomp_press *(float)uncomp_press;
	partial_data2 = cal->par_p9 + cal->par_p10 * cal->t_lin;
	partial_data3 = partial_data1 * partial_data2;
	partial_data4 = partial_data3 + (((float)uncomp_press * (float)uncomp_press * (float)uncomp_press) * cal->par_p11);
	comp_press = partial_out1 + partial_out2 + partial_data4;

	return comp_press;

}



bool BM388_DataCalibration(BMP388_Calib *cal){
	// Ensure we got a proper pointer if not return false
	if(!cal){
		return false;
	}

	uint8_t data[21]; // buffer for data registers (NVM registers)

	HAL_StatusTypeDef readData = HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, NVNPAT1, I2C_MEMADD_SIZE_8BIT, data, sizeof data, HAL_MAX_DELAY);
	if (readData == HAL_OK){
		// Read all data again but this time with each register being their designated signed or unsigned



		 	// Temperature Data
		uint16_t T1 = ((uint16_t)data[1] << 8) | data[0]; // unsigned
		uint16_t T2 = ((uint16_t)data[3] << 8) | data[2]; // unsigned
		int8_t 	 T3 = (int8_t)data[4];					  // signed data

		// Pressure Sensor Data
		int16_t  P1 = (int16_t) (((uint16_t) data[6] << 8) | (uint16_t) data[5]); // signed data
		int16_t  P2 = (int16_t)(((uint16_t) data[8] << 8) | (uint16_t) data[7]); // signed data
		int8_t   P3 = (int8_t) data[9]; 							  // signed data
		int8_t 	 P4 = (int8_t) data[10];							  // signed data
		uint16_t P5 = (int16_t)((uint16_t) data[12] << 8) | (uint16_t)data[11]; 	  // unsigned data
		uint16_t P6 = (int16_t)((uint16_t) data[14] << 8) | (uint16_t)data[13];	  // unsigned data
		int8_t   P7 = (int8_t) data[15];						  // signed data
		int8_t   P8 = (int8_t) data[16];						  // signed data
		int16_t  P9 = (int16_t)(((uint16_t) data[18] << 8) | (uint16_t) data[17]); // signed data
		int8_t   P10 = (int8_t) data[19]; 							// signed data
		int8_t   P11 = (int8_t) data[20];							// signed data


		/*
		// Temperature Data
		uint16_t T1 = ((uint16_t)data[1] << 8) | data[0]; // unsigned
		uint16_t T2 = ((uint16_t)data[3] << 8) | data[2]; // unsigned
		int8_t 	 T3 = (int8_t)data[4];					  // signed data

		// Pressure Sensor Data
		int16_t  P1 = ((int16_t) data[6] << 8) | (int8_t) data[5]; // signed data
		int16_t  P2 = ((int16_t) data[8] << 8) | (int8_t) data[7]; // signed data
		int8_t   P3 = (int8_t) data[9]; 							  // signed data
		int8_t 	 P4 = (int8_t) data[10];							  // signed data
		uint16_t P5 = ((uint16_t) data[12] << 8) | data[11]; 	  // unsigned data
		uint16_t P6 = ((uint16_t) data[14] << 8) | data[13];	  // unsigned data
		int8_t   P7 = (int8_t) data[15];						  // signed data
		int8_t   P8 = (int8_t) data[16];						  // signed data
		int16_t  P9 = ((int16_t) data[18] << 8) | (int8_t) data[17]; // signed data
		int8_t   P10 = (int8_t) data[19]; 							// signed data
		int8_t   P11 = (int8_t) data[20];							// signed data
		*/


		// Calibration coefficient for Temperature NVM data
		cal->par_t1 = (float)T1 / (float)pow(2, -8);
		cal->par_t2 = (float)T2 / (float)pow(2, 30);
		cal->par_t3 = (float)T3 / (float)pow(2, 48);

		// Calibration coefficient for Pressure NVM data
		cal->par_p1 = (float)(P1 - (float)pow(2, 14)) / (float)pow(2, 20);
		cal->par_p2 = (float)(P2 - (float)pow(2, 14)) / (float)pow(2, 29);
		cal->par_p3 = (float)P3 / (float)pow(2, 32);
		cal->par_p4 = (float)P4 / (float)pow(2, 37);
		cal->par_p5 = (float)P5 / (float)pow(2, -3);
		cal->par_p6 = (float)P6 / (float)pow(2,6);
		cal->par_p7 = (float)P7 / (float)pow(2, 8);
		cal->par_p8 = (float)P8 / (float)pow(2, 15);
		cal->par_p9 = (float)P9 / (float)pow(2, 48);
		cal->par_p10 = (float)P10 / (float)pow(2, 48);
		cal->par_p11 = (float)P11 / (float)pow(2, 65);

		cal->t_lin = 0.0f; // set value to float 0 rather than a random garbage number
		return true;
	}else{
		return false;
	}

}


/*
 *  Formula for altitude
 *  altitude = 44330 * (1-(pressure / SeaLevelPressure)^(1/5.255) // this formula was given in the drone Youtube Video
 *
 *
 */



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


bool BMP388_ReadData(BMP388_Calib *cal, float* temp_c, float* press_Pa, float *altitude_m) {
	if (!cal)return false;

	uint8_t status = 0;
	do {
		if (HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, STATUS, I2C_MEMADD_SIZE_8BIT, &status, 1, HAL_MAX_DELAY) != HAL_OK)
			return false;
	} while ((status & ((1 << 5) | (1 << 6))) == 0); // press or temp ready

	// burst read
	uint8_t rawData[6];
	// Data_0 is the address for starting register of Pressure Data and then the following 6 registers are for the remaining 2 Pressure sensor data
	// and the following 3 are for the Temperature Sensor Data. So it goes from Data_0 to Data_5. This is why we need a register with 6 elements for each
	// 8 bit data output from each sensor

	// conditional statement checks to see that we acquire all data from the 6 registers
	if (HAL_I2C_Mem_Read(&hi2c1, BMP388_I2C_Address, Data_0, I2C_MEMADD_SIZE_8BIT, rawData, 6, HAL_MAX_DELAY) != HAL_OK) {
		return false;
	}

	// put together 24 bit raw unsigned data: check page 31 for reference
	uint32_t pressureData = (((uint32_t)rawData[2] << 16) | ((uint16_t) rawData[1] << 8) | rawData[0]);
	uint32_t tempData = (((uint32_t)rawData[5] << 16) | ((uint16_t) rawData[4] << 8) | rawData[3]);


	// compensation
	float tc = BMP388_compensate_temperature(tempData, cal);
	float pPA  = BMP388_compensate_pressure(pressureData, cal); // unit(Pa)

	//float a_m =
    //float tc = bmp388_comp_temp(tempData, cal);
	//float pPA  = bmp388_comp_press(pressureData, cal);


	// checks to see if a valid pointer is passed and isn't NULL
	if (temp_c){
		*temp_c = tc;
	}
	if (press_Pa) {
		*press_Pa = pPA;
	}

	if (altitude_m){
		//altitude = 44330 * (1-((pressure/100) / SeaLevelPressure)^(1/5.255) // this formula was given in the drone Youtube Video
		float pressure = (float)(pPA / 100) / (float)SeaLevelPressure;
		float exponent = (float)(1/5.255);
		float p = pow(pressure, exponent);
		float p2 = 1 - p;
		float calculatedAlt = 44330 * (1 - (float)pow(pressure, exponent));
		*altitude_m = calculatedAlt;
	}
	return true;
}

