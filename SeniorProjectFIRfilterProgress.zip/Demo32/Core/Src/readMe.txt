So far this progam works, like the one for the final project in CECS 447
Only caviot is that I have not implemented interrupts or even the Z angle 
properly. So as the project progresses I shall include interrupts to provide
accurate data by triggering an interrupt when we have a complete package from
the IMU. Then we will process that data from the MPU6050