/*
 * uart5.c
 *
 *  Created on: November 2, 2025
 *      Author: Jordan H. and James H.
 *      Description: Initialize UART5 for LoRa module
 */

#include "main.h"
#include "uart5.h"
#include <string.h>

UART_HandleTypeDef huart5; // UART5 handler

static void UART5_GPIO_Init(void){
	// Enable GPIOC/GPIOD for PC12/PD2
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();

	GPIO_InitTypeDef g = {0};
	g.Mode = GPIO_MODE_AF_PP;
	g.Pull = GPIO_PULLUP;
	g.Speed = GPIO_SPEED_FREQ_VERY_HIGH;

	// PC12 -> UART5_TX (to E32 DIN)
	g.Pin = GPIO_PIN_12;
	g.Alternate = GPIO_AF8_UART5;
	HAL_GPIO_Init(GPIOC, &g);

	// PD2  -> UART5_RX (from E32 DOUT)
	g.Pin = GPIO_PIN_2;
	g.Alternate = GPIO_AF8_UART5;
	HAL_GPIO_Init(GPIOD, &g);
}

void UART5_LoRa_Init(void) // Initialize UART5 for LoRa module
{
    UART5_GPIO_Init();

    // Enable the UART5 peripheral clock
    __HAL_RCC_UART5_CLK_ENABLE();

    // Configure UART5: 9600, 8-N-1 to for E32 LoRa module
    huart5.Instance        = UART5;
    huart5.Init.BaudRate   = 115200;
    huart5.Init.WordLength = UART_WORDLENGTH_8B;
    huart5.Init.StopBits   = UART_STOPBITS_1;
    huart5.Init.Parity     = UART_PARITY_NONE;
    huart5.Init.Mode       = UART_MODE_TX_RX;
    huart5.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
    huart5.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart5) != HAL_OK) {
        Error_Handler();
    }
}

// Helper function for main function
void UART5_SendBytes(const uint8_t* data, uint16_t len, uint32_t timeout_ms)
{
    (void)HAL_UART_Transmit(&huart5, (uint8_t*)data, len, timeout_ms);
}

// Main function
void UART5_SendString(const char* s, uint32_t timeout_ms)
{
	UART5_SendBytes((const uint8_t*)s, (uint16_t)strlen(s), timeout_ms);
}
